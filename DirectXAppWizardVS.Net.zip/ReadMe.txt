This is the DirectX Application Wizard converted for use in Visual Studio.Net.

To install the wizard
1.	Copy all of the sample files to your hard disk.
2.	Copy the contents of the VCProjects folder to the Vc7\VCProjects folder in the directory where Visual Studio is installed. (for example, c:\Program Files\Microsoft Visual Studio .NET\Vc7\VCProjects\).
3.	Copy the contents of the VCwizards folder to the Vc7\VCWizards folder in the directory where Visual Studio is installed. (for example, c:\Program Files\Microsoft Visual Studio .NET\Vc7\VCWizards\).

The wizard will be available the next time that you select File, New Project in Visual Studio. See the sample abstract in online help for more information.

Please note: This wizard is unspported by either myself or Microsoft, but if you think you have a fix to any problems that may arise, please let me know.

Scott Chappel
schappel@bigpond.net.au

