//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by [!output PROJECT_NAME].rc
//
#define IDI_MAIN_ICON                   101
#define IDD_[!output SAFE_ROOT]_DIALOG		102
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDC_OUTPUT_LINE1                227
#define IDC_OUTPUT_LINE2                228
#define IDC_OUTPUT_LINE3                229
#define IDC_OUTPUT_LINE4                230
#define IDC_OUTPUT_LINE5                231
#define IDC_OUTPUT_LINE6                232
#define IDC_OUTPUT_LINE7                233
#define IDC_OUTPUT_LINE8                234
#define IDC_OUTPUT_LINE9                235
#define IDC_OUTPUT_LINE10               236
#define IDC_OUTPUT_LINE11               237
#define IDD_MULTIPLAYER_CONNECT         10001
#define IDD_MULTIPLAYER_GAMES           10002
#define IDD_MULTIPLAYER_CREATE          10003
#define IDD_LOBBY_WAIT_STATUS           10004
#define IDC_PLAYER_NAME_EDIT            11002
#define IDC_GAMES_LIST                  11003
#define IDC_JOIN                        11004
#define IDC_CREATE                      11005
#define IDC_CONNECTION_LIST             11006
#define IDC_BACK                        11007
#define IDC_EDIT_SESSION_NAME           11009
#define IDC_SEARCH_CHECK                11010
#define IDC_WAIT_TEXT                   11012
#define IDD_VOICE_SETUP                 12008
#define IDC_SESSIONCOMPRESION_GROUP     12059
#define IDC_COMPRESSION_COMBO           12060
#define IDC_QUALITY_DEFAULT             12201
#define IDC_QUALITY_SET                 12202
#define IDC_QUALITY_SLIDER              12203
#define IDC_AGGRESSIVENESS_DEFAULT      12301
#define IDC_AGGRESSIVENESS_SET          12302
#define IDC_AGGRESSIVENESS_SLIDER       12303
#define IDC_RECORD_DEFAULT              12501
#define IDC_RECORD_SET                  12502
#define IDC_RECORD_AUTO                 12503
#define IDC_RECORD_SLIDER               12504
#define IDC_THRESHOLD_DEFAULT           12601
#define IDC_THRESHOLD_SET               12602
#define IDC_THRESHOLD_AUTO              12603
#define IDC_THRESHOLD_SLIDER            12604
#define IDC_PLAYBACK_DEFAULT            12701
#define IDC_PLAYBACK_SET                12702
#define IDC_PLAYBACK_SLIDER             12703
#define IDM_EXIT                        40006
#define IDM_CONFIGINPUT                 40011
#define IDM_CONFIGVOICE                 40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        250
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         3000
#define _APS_NEXT_SYMED_VALUE           5000
#endif
#endif
