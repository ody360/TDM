// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
#pragma once

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <windows.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <D3DX8.h>
#include <DXErr8.h>
#include <tchar.h>
[!if SUPPORT_DIRECTINPUT]
#include <dinput.h>
[!endif]
[!if SUPPORT_DIRECTPLAY]
#include <dplay8.h>
#include <dplobby8.h>
[!endif]
#include "D3DApp.h"
[!if SUPPORT_DIRECT3DFONTS]
#include "D3DFont.h"
[!endif]
[!if SUPPORT_DIRECT3DMESHES]
#include "D3DFile.h"
[!endif]
#include "D3DUtil.h"
[!if DIRECTINPUT_ACTIONMAPPING]
#include "DIUtil.h"
[!endif]
[!if SUPPORT_DIRECTMUSIC]
#include "DMUtil.h"
[!endif]
[!if SUPPORT_DIRECTSOUND]
#include "DSUtil.h"
[!endif]
[!if SUPPORT_DIRECTPLAY]
#include "NetConnect.h"
[!endif]
[!if SUPPORT_DIRECTPLAYVOICE]
#include "NetVoice.h"
[!endif]
#include "DXUtil.h"
#include "resource.h"

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.
