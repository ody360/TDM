
function OnFinish(selProj, selObj)
{
	try
	{
		// Turn the group options into a booleans; 
		// this is needed cause if the page has not been displayed then the value is a group choice still
		if( wizard.FindSymbol( 'APPTYPE_SDI' ) )
			wizard.AddSymbol( 'APPTYPE_SDI', true );
		else
			wizard.AddSymbol( 'APPTYPE_MFC', true );
			
		if( wizard.FindSymbol( 'STARTOBJECT_TEAPOT' ) )
			wizard.AddSymbol( 'STARTOBJECT_TEAPOT', true );
		else if( wizard.FindSymbol( 'STARTOBJECT_TRIANGLE' ) )
		  wizard.AddSymbol( 'STARTOBJECT_TRIANBLE', true );
		else
			wizard.AddSymbol( 'STARTOBJECT_BLANK', true );
			
		if( wizard.FindSymbol( 'DIRECTINPUT_ACTIONMAPPING' ) )
			wizard.AddSymbol( 'DIRECTINPUT_ACTIONMAPPING', true );
		else
			wizard.AddSymbol( 'DIRECTINPUT_KEYBOARD', true );
			
			
		// Create a new GUID
		strRawGUID = wizard.CreateGuid();
		wizard.AddSymbol( 'GUIDMSG', wizard.FormatGuid( strRawGUID, 0 ) );
		wizard.AddSymbol( 'GUIDSTRUCT', wizard.FormatGuid( strRawGUID, 2 ) );
	
		var strProjectPath = wizard.FindSymbol('PROJECT_PATH');
		var strProjectName = wizard.FindSymbol('PROJECT_NAME');
		var bMFC = wizard.FindSymbol('APPTYPE_MFC');
		var bD3D = wizard.FindSymbol('SUPPORT_DIRECT3D');

		wizard.AddSymbol( 'CROOT', strProjectName );
		wizard.AddSymbol( 'SAFE_ROOT', strProjectName.toUpperCase() );

		selProj = CreateCustomProject(strProjectName, strProjectPath);
		AddConfig(selProj, strProjectName);
		AddFilters(selProj);

		var InfFile = CreateCustomInfFile();
		AddFilesToCustomProj(selProj, strProjectName, strProjectPath, InfFile);
		PchSettings(selProj);
		InfFile.Delete();

		selProj.Object.Save();
	}
	catch(e)
	{
		if (e.description.length != 0)
			SetErrorInfo(e);
		return e.number
	}
}

function CreateCustomProject(strProjectName, strProjectPath)
{
	try
	{
		var strProjTemplatePath = wizard.FindSymbol('PROJECT_TEMPLATE_PATH');
		var strProjTemplate = '';
		strProjTemplate = strProjTemplatePath + '\\default.vcproj';

		var Solution = dte.Solution;
		var strSolutionName = "";
		if (wizard.FindSymbol("CLOSE_SOLUTION"))
		{
			Solution.Close();
			strSolutionName = wizard.FindSymbol("VS_SOLUTION_NAME");
			if (strSolutionName.length)
			{
				var strSolutionPath = strProjectPath.substr(0, strProjectPath.length - strProjectName.length);
				Solution.Create(strSolutionPath, strSolutionName);
			}
		}

		var strProjectNameWithExt = '';
		strProjectNameWithExt = strProjectName + '.vcproj';

		var oTarget = wizard.FindSymbol("TARGET");
		var prj;
		if (wizard.FindSymbol("WIZARD_TYPE") == vsWizardAddSubProject)  // vsWizardAddSubProject
		{
			var prjItem = oTarget.AddFromTemplate(strProjTemplate, strProjectNameWithExt);
			prj = prjItem.SubProject;
		}
		else
		{
			prj = oTarget.AddFromTemplate(strProjTemplate, strProjectPath, strProjectNameWithExt);
		}
		return prj;
	}
	catch(e)
	{
		throw e;
	}
}

function AddFilters(proj)
{
	try
	{
		var strProjectName = wizard.FindSymbol('PROJECT_NAME');
		var bMFC = wizard.FindSymbol( 'APPTYPE_MFC' );
		var bD3D = wizard.FindSymbol( 'SUPPORT_DIRECT3D' );
		
		// Add the folders to your project
		var group = proj.Object.AddFilter("Source Files");
		group.Filter = "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat";
		
		var group = proj.Object.AddFilter("Header Files");
		group.Filter = "h;hpp;hxx;hm;inl";
		
		var group = proj.Object.AddFilter("Resource Files");
		group.Filter =  "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe;wav";
	}
	catch(e)
	{
		throw e;
	}
}

function AddConfig(proj, strProjectName)
{
	try
	{
		var strProjectName = wizard.FindSymbol('PROJECT_NAME');
		var bMFC = wizard.FindSymbol( 'APPTYPE_MFC' );
		var bDCOM = wizard.FindSymbol( 'SUPPORT_DIRECTPLAY' );
		
		if( bMFC )
			proj.Object.Keyword = "MFCProj";
					
		// Debug configuration and tools
		var config = proj.Object.Configurations('Debug');
		config.IntermediateDirectory = '.\\Debug';
		config.OutputDirectory = '.\\Debug';
		config.UseOfMFC = (bMFC ? '2' : '0');
		config.ATLMinimizesCRunTimeLibraryUsage = 'FALSE';
		config.CharacterSet= '2';

		var CLTool = config.Tools('VCCLCompilerTool');
		CLTool.Optimization='0';
		var preProcessDefn = 'WIN32;_DEBUG;_WINDOWS';
		if( bDCOM )
			preProcessDefn += ';_WIN32_DCOM';
		CLTool.PreprocessorDefinitions = preProcessDefn;
		CLTool.BasicRunTimeChecks = '3';
		if( bMFC )
		{
			CLTool.RunTimeLibrary = '3';
			CLTool.UsePrecompiledHeader = '3';
			CLTool.PrecompiledHeaderThrough = "stdafx.h";
		}
		else
		{
			CLTool.RunTimeLibrary = '5';
			CLTool.UsePrecompiledHeader = '2';
		}
		CLTool.PrecompiledHeaderFile = ".\\Debug/" + strProjectName + ".pch";
		CLTool.AssemblerListingLocation = ".\\Debug/";
		CLTool.ObjectFile = ".\\Debug/";
		CLTool.ProgramDataBaseFileName = ".\\Debug/";
		CLTool.WarningLevel = "3";
		CLTool.SuppressStartupBanner = "TRUE";
		CLTool.DebugInformationFormat = "4";

		var CustomBuildTool = config.Tools('VCCustomBuildTool');

		var LinkTool = config.Tools('VCLinkerTool');
		LinkTool.AdditionalOptions="/MACHINE:I386";
		LinkTool.AdditionalDependencies="dsound.lib dinput8.lib dxerr8.lib d3dx8dt.lib d3d8.lib d3dxof.lib dxguid.lib winmm.lib" + (bMFC ? "" :" odbc32.lib odbccp32.lib");
		LinkTool.OutputFile=".\\Debug/" + strProjectName + ".exe";
		LinkTool.LinkIncremental="2";
		LinkTool.SuppressStartupBanner="TRUE";
		LinkTool.GenerateDebugInformation="TRUE";
		LinkTool.ProgramDatabaseFile=".\\Debug/" + strProjectName + ".pdb";
		LinkTool.SubSystem="2";
		
		var MIDLTool = config.Tools('VCMIDLTool');
		MIDLTool.PreprocessorDefinitions="_DEBUG";
		MIDLTool.MkTypLibCompatible="TRUE";
		MIDLTool.SuppressStartupBanner="TRUE";
		MIDLTool.TargetEnvironment="1";
		MIDLTool.TypeLibraryName=".\\Debug/" + strProjectName + ".tlb";
		
		var PostBuildEventTool = config.Tools('VCPostBuildEventTool');
		
		var PreBuildEventTool = config.Tools('VCPreBuildEventTool');
		
		var PreLinkEventTool = config.Tools('VCPreLinkEventTool');
		
		var ResourceCompilerTool = config.Tools('VCResourceCompilerTool');
		ResourceCompilerTool.PreprocessorDefinitions = (bMFC ? "_AFXDLL;_DEBUG" : "_DEBUG");
		ResourceCompilerTool.Culture = "3081";
		// end Debug configuration information and tools

		// Release configuration and tools
		config = proj.Object.Configurations('Release');
		config.OutputDirectory = '.\\Release';
		config.IntermediateDirectory = '.\\Release';
		config.ConfigurationType = "1";
		config.UseOfMFC = (bMFC ? "2" : "0");
		config.ATLMinimizesCRunTimeLibraryUsage = "FALSE";
		config.CharacterSet = "2";
		

		var CLTool = config.Tools('VCCLCompilerTool');
		CLTool.InlineFunctionExpansion="1";
		var preProcessDefn = "WIN32;NDEBUG;_WINDOWS";
		if( bDCOM )
			preProcessDefn += ";_WIN32_DCOM";
		CLTool.PreprocessorDefinitions = preProcessDefn;
		CLTool.StringPooling = "TRUE";
		CLTool.RuntimeLibrary = (bMFC ? "2" : "4" );
		CLTool.EnableFunctionLevelLinking = "TRUE";
		CLTool.UsePrecompiledHeader = (bMFC ? "3" : "2" );
		if( bMFC )
			CLTool.PrecompiledHeaderThrough = "stdafx.h";
		CLTool.PrecompiledHeaderFile = ".\\Release/" + strProjectName +".pch";
		CLTool.AssemblerListingLocation = ".\\Release/";
		CLTool.ObjectFile = ".\\Release/";
		CLTool.ProgramDataBaseFileName = ".\\Release/";
		CLTool.WarningLevel = "3";
		CLTool.SuppressStartupBanner = "TRUE";

		var CustomBuildTool = config.Tools('VCCustomBuildTool');

		var LinkTool = config.Tools('VCLinkerTool');
		LinkTool.AdditionalOptions = "/MACHINE:I386";
		LinkTool.AdditionalDependencies = "dsound.lib dinput8.lib dxerr8.lib d3dx8dt.lib d3d8.lib d3dxof.lib dxguid.lib winmm.lib" + (bMFC ? "" : " odbc32.lib odbccp32.lib");
		LinkTool.OutputFile = ".\\Release/" + strProjectName + ".exe";
		LinkTool.LinkIncremental = "1";
		LinkTool.SuppressStartupBanner = "TRUE";
		LinkTool.ProgramDatabaseFile = ".\\Release" + strProjectName + ".pdb";
		LinkTool.SubSystem = "2";
		
		var MIDLTool = config.Tools('VCMIDLTool');
		MIDLTool.PreprocessorDefinitions = "NDEBUG";
		MIDLTool.MkTypLibCompatible = "TRUE";
		MIDLTool.SuppressStartupBanner = "TRUE";
		MIDLTool.TargetEnvironment = "1";
		MIDLTool.TypeLibraryName = ".\\Release/" + strProjectName + ".tlb";

		var PostBuildEventTool = config.Tools('VCPostBuildEventTool');
		
		var PreBuildEventTool = config.Tools('VCPreBuildEventTool');
		
		var PreLinkEventTool = config.Tools('VCPreLinkEventTool');
		
		var ResourceCompilerTool = config.Tools('VCResourceCompilerTool');
		ResourceCompilerTool.PreprocessorDefinitions = (bMFC ? "_AFXDLL;NDEBUG" : "NDEBUG");
		ResourceCompilerTool.Culture = "3081";
		
		var WebServiceProxyGeneratorTool = config.Tools('VCWebServiceProxyGeneratorTool');
		
		var WebDeploymentTool = config.Tools('VCWebDeploymentTool');
		// end Release configuration and tools
	}
	catch(e)
	{
		throw e;
	}
}

function PchSettings(proj)
{
	var bMFC = wizard.FindSymbol( 'APPTYPE_MFC' );

	if( bMFC )
	{
		var filter = proj.Object.Filters( "Source Files" );
	  var file = filter.Files( "StdAfx.cpp" );
		var config = file.FileConfigurations( "Debug|Win32" );
		config.Tool.UsePrecompiledHeader = pchCreateUsingSpecific;

		var config = file.FileConfigurations( "Release|Win32" );
		config.Tool.UsePrecompiledHeader = pchCreateUsingSpecific;
	}
}

function DelFile(fso, strWizTempFile)
{
	try
	{
		if (fso.FileExists(strWizTempFile))
		{
			var tmpFile = fso.GetFile(strWizTempFile);
			tmpFile.Delete();
		}
	}
	catch(e)
	{
		throw e;
	}
}

function CreateCustomInfFile()
{
	try
	{
		var fso, TemplatesFolder, TemplateFiles, strTemplate;
		fso = new ActiveXObject('Scripting.FileSystemObject');

		var TemporaryFolder = 2;
		var tfolder = fso.GetSpecialFolder(TemporaryFolder);
		var strTempFolder = tfolder.Drive + '\\' + tfolder.Name;

		var strWizTempFile = strTempFolder + "\\" + fso.GetTempName();

		var strTemplatePath = wizard.FindSymbol('TEMPLATES_PATH');
		var strInfFile = strTemplatePath + '\\Templates.inf';
		wizard.RenderTemplate(strInfFile, strWizTempFile);

		var WizTempFile = fso.GetFile(strWizTempFile);
		return WizTempFile;
	}
	catch(e)
	{
		throw e;
	}
}

function GetTargetName(strName, strProjectName)
{
	try
	{
		var strProjectName = wizard.FindSymbol('PROJECT_NAME');

		// TODO: set the name of the rendered file based on the template filename
		var strTarget = strName;

		if (strName == 'readme.txt') strTarget = 'ReadMe.txt';
		// SUPPORT_DIRECT3D && APPTYPE_SDI
		if (strName == 'd3d_win.cpp') strTarget = strProjectName + '.cpp';
		if (strName == 'd3d_win.h') strTarget = strProjectName + '.h';
		if (strName == 'd3d_win.rc') strTarget = strProjectName + '.rc';
		if (strName == 'd3d_winres.h') strTarget = 'resource.h';
		// SUPPORT_DIRECT3D && APPTYPE_MFC
		if (strName == 'd3d_dlg.cpp') strTarget = strProjectName + '.cpp';
		if (strName == 'd3d_dlg.h') strTarget = strProjectName + '.h';
		if (strName == 'd3d_dlg.rc') strTarget = strProjectName + '.rc';
		if (strName == 'd3d_dlgres.h') strTarget = 'resource.h';
		if (strName == 'd3d_dlgStdAfx.cpp') strTarget = 'StdAfx.cpp';
		if (strName == 'd3d_dlgStdAfx.h') strTarget = 'StdAfx.h';
		// !SUPPORT_DIRECT3D && APPTYPE_SDI
		if (strName == 'gdi_win.cpp') strTarget = strProjectName + '.cpp';
		if (strName == 'gdi_win.h') strTarget = strProjectName + '.h';
		if (strName == 'gdi_win.rc') strTarget = strProjectName + '.rc';
		if (strName == 'gdi_winres.h') strTarget = 'resource.h';
		// !SUPPORT_DIRECT3D && APPTYPE_MFC
		if (strName == 'gdi_dlg.cpp') strTarget = strProjectName + '.cpp';
		if (strName == 'gdi_dlg.h') strTarget = strProjectName + '.h';
		if (strName == 'gdi_dlg.rc') strTarget = strProjectName + '.rc';
		if (strName == 'gdi_dlgres.h') strTarget = 'resource.h';
		if (strName == 'gdi_dlgStdAfx.cpp') strTarget = 'StdAfx.cpp';
		if (strName == 'gdi_dlgStdAfx.h') strTarget = 'StdAfx.h';


		return strTarget; 
	}
	catch(e)
	{
		throw e;
	}
}

function AddFilesToCustomProj(proj, strProjectName, strProjectPath, InfFile)
{
	try
	{
		var projItems = proj.ProjectItems

		var strTemplatePath = wizard.FindSymbol('TEMPLATES_PATH');

		var strTpl = '';
		var strName = '';

		var strTextStream = InfFile.OpenAsTextStream(1, -2);
		while (!strTextStream.AtEndOfStream)
		{
			strTpl = strTextStream.ReadLine();
			if (strTpl != '')
			{
				strName = strTpl;
				var strTarget = GetTargetName(strName, strProjectName);
				var strTemplate = strTemplatePath + '\\' + strTpl;
				var strFile = strProjectPath + '\\' + strTarget;

				var bCopyOnly = false;  //"true" will only copy the file from strTemplate to strTarget without rendering/adding to the project
				var strExt = strName.substr(strName.lastIndexOf("."));
				if(strExt==".bmp" || strExt==".ico" || strExt==".gif" || strExt==".rtf" || strExt==".css" || strExt==".wav")
					bCopyOnly = true;
				wizard.RenderTemplate(strTemplate, strFile, bCopyOnly);
				proj.Object.AddFile(strFile);
			}
		}
		strTextStream.Close();
	}
	catch(e)
	{
		throw e;
	}
}
