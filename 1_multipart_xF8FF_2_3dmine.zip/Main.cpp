#include "Includes.h"

// Constants to make changing stuff in initialization easier
D3DDISPLAYMODE g_displayMode;
const int WINDOW_X = 0; 
const int WINDOW_Y = 0; 
const char *WINDOW_TITLE="3D Minesweeper";
const char *WINDOW_CLASS_NAME="3D Minesweeper"; 

// Important Windows variables
HINSTANCE g_hInst;
HWND g_hWnd;


// Whether or not it's fullscreen
bool g_bFullscreen;

int iRotationDegreesX = 0;
int iRotationDegreesY = 0;
float g_fDistanceToCamera = 0;

// Important Direct3D variables
IDirect3D8 *g_pDirect3D;
IDirect3DDevice8 *g_pDevice;

// The one and only minefield
CMineField g_theField;

// Results from Direct3D function calls are stored here
HRESULT g_hr;

BOOL CALLBACK DialogProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int index = 0;
	char temp[128];
    UINT nModes = 0;
	D3DDISPLAYMODE displayMode;

	switch (message)
    {
    case WM_INITDIALOG:
		index = 0;
		nModes = g_pDirect3D->GetAdapterModeCount( D3DADAPTER_DEFAULT );
		memset( &displayMode, 0, sizeof(D3DDISPLAYMODE) );
		
		for( int i = nModes-1; i >= 0; i-- )
		{
			if( D3D_OK == g_pDirect3D->EnumAdapterModes( D3DADAPTER_DEFAULT, i, &g_displayMode ) )
			{
				if( ( displayMode.Width != g_displayMode.Width ||	// cull out low refresh rates..
					displayMode.Height != g_displayMode.Height ||
					displayMode.Format != g_displayMode.Format ) && 
					g_displayMode.Width > 512 ) // cull out low resolutions
				{
					g_displayMode.RefreshRate = 0; // forces default

					if( g_displayMode.Format == D3DFMT_X8R8G8B8 ||
						g_displayMode.Format == D3DFMT_A8R8G8B8 ||
						g_displayMode.Format == D3DFMT_R8G8B8 )
						sprintf( temp, "%iX%iX32", g_displayMode.Width, g_displayMode.Height );
					else
						sprintf( temp, "%iX%iX16", g_displayMode.Width, g_displayMode.Height );

					SendMessage( GetDlgItem(hwnd,IDC_RES_BOX), CB_INSERTSTRING, (WPARAM)index, (LPARAM)&temp );
					SendMessage( GetDlgItem(hwnd,IDC_RES_BOX), CB_SETITEMDATA, (WPARAM)index, (LPARAM)(DWORD)i );
					index++;
				}
				displayMode = g_displayMode;
			}
		}
		index = SendMessage( GetDlgItem(hwnd,IDC_RES_BOX), CB_GETCOUNT, 0, 0);
		SendMessage( GetDlgItem(hwnd,IDC_RES_BOX), CB_SETCURSEL, (WPARAM)index/2, 0 );
		CheckDlgButton( hwnd, IDC_FULLSCREEN, BST_CHECKED );
        return TRUE;
    case WM_COMMAND:

		switch (LOWORD(wParam)) 
        { 
            case IDOK:
				UINT selItem;
				UINT displayModeID;
				selItem = SendMessage( GetDlgItem(hwnd,IDC_RES_BOX), CB_GETCURSEL, 0, 0);
				
				// get selected display mode
				displayModeID = SendMessage( GetDlgItem(hwnd,IDC_RES_BOX),
											CB_GETITEMDATA, (WPARAM)selItem, 0);

				g_pDirect3D->EnumAdapterModes( D3DADAPTER_DEFAULT, displayModeID, &g_displayMode );

				// get fullscreen
				if( IsDlgButtonChecked( hwnd, IDC_FULLSCREEN) == BST_CHECKED )
					g_bFullscreen = true;
				else
					g_bFullscreen = false;

				// fall through
			case IDCANCEL:
				EndDialog(hwnd, wParam); 
				return TRUE;
		}
        return TRUE;
    case WM_DESTROY:
        //PostQuitMessage(0);
        return TRUE;
    case WM_CLOSE:
        DestroyWindow (hwnd);
        return TRUE;
    }
    return FALSE;
}

bool SetupDirectX()
{
    if( DialogBox(g_hInst, MAKEINTRESOURCE(IDD_SETUP), 0, DialogProc) == IDOK )
		return TRUE;
	else
		return FALSE;
}

// this is called during program init, and if we loose the device
bool LoadD3Device()
{
	// Set up a structure with either the current display mode for windowed mode or the desired display mode for fullscreen
	g_displayMode.RefreshRate=0; // forces default mode..

	if( g_bFullscreen == false )
	{
		g_displayMode.Width=320;
		g_displayMode.Height=240;
		g_displayMode.Format=D3DFMT_R5G6B5;
	}

	// Setup the present parameters
	D3DPRESENT_PARAMETERS presentParameters;
	memset(&presentParameters, 0, sizeof(D3DPRESENT_PARAMETERS));
	if (g_bFullscreen==false)
		presentParameters.Windowed   = TRUE;
	else
		presentParameters.Windowed   = FALSE;

	presentParameters.SwapEffect = D3DSWAPEFFECT_DISCARD;
	presentParameters.BackBufferFormat = g_displayMode.Format;
	presentParameters.BackBufferWidth = g_displayMode.Width;
	presentParameters.BackBufferHeight = g_displayMode.Height;

	// zbuffer setup
	presentParameters.AutoDepthStencilFormat = D3DFMT_D16;
	presentParameters.EnableAutoDepthStencil = TRUE;

	// Create the device
	g_hr=g_pDirect3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, g_hWnd,
                                  D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                  &presentParameters, &g_pDevice ); 
	if (FAILED(g_hr))
		return false;

	g_theField.NewGame(iCoords(5,5,5), 50 );
	g_theField.RebuildVertexBuffer( g_pDevice );


	//Let there be light
	D3DLIGHT8 d3dLight;

	//Initialize the light structure.
	ZeroMemory(&d3dLight, sizeof(D3DLIGHT8));

	//Set up a white point light at (0, 0, -10).
	d3dLight.Type = D3DLIGHT_POINT;

	d3dLight.Diffuse.r = 1.0f;
	d3dLight.Diffuse.g = 1.0f;
	d3dLight.Diffuse.b = 1.0f;

	d3dLight.Ambient.r = 0.0f;
	d3dLight.Ambient.g = 0.0f;
	d3dLight.Ambient.b = 0.0f;

	d3dLight.Specular.r = 0.0f;
	d3dLight.Specular.g = 0.0f;
	d3dLight.Specular.b = 0.0f;

	d3dLight.Position.x = 0.0f;
	d3dLight.Position.y = 0.0f;
	d3dLight.Position.z = -g_fDistanceToCamera;

	d3dLight.Attenuation0 = 0.05f; 
	d3dLight.Attenuation1 = 0.05f; 
	d3dLight.Attenuation2 = 0.0f;
	d3dLight.Range = 100.0;

	//Assign the point light to our device in poisition (index) 0
	g_pDevice->SetLight(0, &d3dLight);

	//Enable our point light in position (index) 0
	g_pDevice->LightEnable(0, TRUE);

	//Turn on lighting
	g_pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);

	//Set ambient light level
	g_pDevice->SetRenderState(D3DRS_AMBIENT, D3DCOLOR_XRGB(32, 32, 32));

	// Matrix code
	D3DXMATRIX mat;
	
	D3DXMatrixPerspectiveFovLH(&mat, D3DX_PI/6, (float)g_displayMode.Width/(float)g_displayMode.Height, 1.0, 100.0);
	g_pDevice->SetTransform(D3DTS_PROJECTION, &(D3DMATRIX)mat);

	D3DXMatrixIdentity(&mat);
	g_pDevice->SetTransform(D3DTS_WORLD, &(D3DMATRIX)mat);

	D3DXMatrixTranslation(&mat, 0, 0, g_fDistanceToCamera);
	g_pDevice->SetTransform(D3DTS_VIEW, &(D3DMATRIX)mat);

	return true;
}

bool Direct3DInit()
{
	// Create the IDirect3D object
	g_pDirect3D=Direct3DCreate8(D3D_SDK_VERSION);
	if (g_pDirect3D==NULL)
		return 0;
	
	if( !SetupDirectX() )
		return 0;

	return true;
}


void UpdateScene()
{
	// We have a static integer for how many degrees to generate the rotation matrix for
	D3DLIGHT8 Light;
	
	D3DXMATRIX matRotationX;
	D3DXMATRIX matRotationY;
	D3DXMATRIX matTrans;
	D3DXMATRIX matRotate;
	D3DXMATRIX matFinal;

	if( GetAsyncKeyState(VK_LEFT) )
		iRotationDegreesX++;
	if( GetAsyncKeyState(VK_RIGHT) )
		iRotationDegreesX--;
	if( GetAsyncKeyState(VK_UP) )
		iRotationDegreesY++;
	if( GetAsyncKeyState(VK_DOWN) )
		iRotationDegreesY--;

	//iRotationDegreesX++;
	//iRotationDegreesY++;

	// Setup a matrix to rotate iRotationDegrees degrees around the Y axis
	D3DXMatrixRotationY(&matRotationX, D3DXToRadian(iRotationDegreesX));
	D3DXMatrixRotationX(&matRotationY, D3DXToRadian(iRotationDegreesY));

	// Increment the degree of rotation. 
	if (abs(iRotationDegreesY)==360)
		iRotationDegreesY=0;
	if (abs(iRotationDegreesX)==360)
		iRotationDegreesX=0;

	D3DXMatrixTranslation(&matTrans, 0, 0, g_fDistanceToCamera );
	D3DXMatrixMultiply(&matRotate, &matRotationX, &matRotationY);
	D3DXMatrixMultiply(&matFinal, &matRotate, &matTrans);
	
	// following keeps the light position the same as the camera
	if( SUCCEEDED( g_pDevice->GetLight( 0, &Light ) ) )
	{
		D3DXMATRIX matInvsFinal;
		float det;

		// turns out the invers of the translation matrix's bottom row
		// is the position of the camera..
		D3DXMatrixInverse( &matInvsFinal, &det, &matFinal );

		Light.Position.x = matInvsFinal._41;
		Light.Position.y = matInvsFinal._42;
		Light.Position.z = matInvsFinal._43;

		g_pDevice->SetLight(0, &Light );
	}

	// Set that matrix to the world transformation
	g_pDevice->SetTransform(D3DTS_VIEW, &matFinal );

}


void DrawScene()
{
	g_theField.Redraw();
}

void Direct3DRelease()
{

	// Release the device
	if (g_pDevice)
		g_pDevice->Release();
	g_pDevice=NULL;

	// Release the Direct3D object
	if (g_pDirect3D)
		g_pDirect3D->Release();
	g_pDirect3D=NULL;
}

// Windows message processing function
LRESULT CALLBACK WndProc(HWND wpHWnd, 
						    UINT msg, 
                            WPARAM wParam, 
                            LPARAM lParam)
{


	switch(msg)
	{	
		case WM_MOUSEMOVE:
			g_theField.OnMouseMove( GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam), wParam );

			// Update the scene each frame
			UpdateScene();
			// Draw the scene each frame
			DrawScene();

			break;
		case WM_LBUTTONDOWN:
			g_theField.OnMouseClick( GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam), wParam );

			UpdateScene();
			DrawScene();

			break;
		case WM_TIMER:
			UpdateScene();
			DrawScene();
			break;
		case WM_DESTROY: 
			PostQuitMessage(0);
			return 0;
		case WM_KEYDOWN:
			if( wParam == VK_ESCAPE )
				PostQuitMessage(0);
			break;

		default:break; 
	} 


	return DefWindowProc(wpHWnd, msg, wParam, lParam);
}
 

int WINAPI WinMain(	HINSTANCE hInstance, 
					HINSTANCE hPrevInstance, 
					LPSTR lpCmdLine, 
					int nCmdShow) 
{

	WNDCLASSEX winClass; 
	MSG msg;	

	// Set our global HINSTANCE to the one we get passed
	g_hInst=hInstance;

	// Setup and register the window class
	winClass.cbSize         = sizeof(WNDCLASSEX); 
	winClass.style			= CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	winClass.lpfnWndProc	= WndProc; 
	winClass.cbClsExtra		= 0;
	winClass.cbWndExtra		= 0; 
	winClass.hInstance		= g_hInst; 
	winClass.hIcon			= LoadIcon(NULL, IDI_APPLICATION); 
	winClass.hCursor		= LoadCursor(NULL, IDC_ARROW); 
	winClass.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH); 
	winClass.lpszMenuName	= NULL; 
	winClass.lpszClassName	= WINDOW_CLASS_NAME; 
	winClass.hIconSm        = LoadIcon(NULL, IDI_APPLICATION);

	if (!RegisterClassEx(&winClass)) 
		return 0;

	// Try to initialize the Direct3D parts of our program. If it fails, make sure everything they might have been created gets released.
	if (Direct3DInit()==false)
	{
		Direct3DRelease();
		return 0;
	}

	if (g_bFullscreen==false)
	{
		// Create a normal window with a border, a caption, and an X button
		g_hWnd = CreateWindowEx(WS_EX_CLIENTEDGE,  
							 WINDOW_CLASS_NAME,     
							 WINDOW_TITLE, 
							 WS_SYSMENU | WS_BORDER | WS_CAPTION | WS_VISIBLE, 
					 		 WINDOW_X, WINDOW_Y ,
							 g_displayMode.Width, g_displayMode.Height,
							 NULL,
							 NULL,
							 g_hInst,  
							 NULL);	
	}
	else
	{
		// Create a fullscreen window, one that doesn't have anything in it
		g_hWnd = CreateWindowEx(NULL,  
							 WINDOW_CLASS_NAME,     
							 WINDOW_TITLE, 
							 WS_POPUP | WS_VISIBLE, 
					 		 WINDOW_X, WINDOW_Y ,
							 g_displayMode.Width, g_displayMode.Height,
							 NULL,
							 NULL,
							 g_hInst,  
							 NULL);		
		

	}
	
	// Make sure the window was created properly. If it wasn't, quit.
	if (!g_hWnd) 
		return 0; 
	
	LoadD3Device(); // loads d3d device..

	SetTimer( g_hWnd, 0, 20, 0);



	while(1)
	{
		// Windows message stuff
		while (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{ 
		    //TranslateMessage(&msg);
		    DispatchMessage(&msg); 

			if (msg.message == WM_QUIT)
				break;
		}
		
		if (msg.message==WM_QUIT)
			break;

		// Quit if the users presses escape
		if (GetAsyncKeyState(VK_ESCAPE))
			PostQuitMessage(0);

	} 

	// Release Direct3D
	Direct3DRelease();


	return 0;
} 