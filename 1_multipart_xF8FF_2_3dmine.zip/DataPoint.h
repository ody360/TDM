#pragma once
#include "Includes.h"

enum state { covered = 0, uncovered = 1, marked = 2 };

class CDataPoint
{
public:
	CDataPoint(void);
	~CDataPoint(void);
	BOOL isUncovered();
	void setUncovered();
	void setFlagged(BOOL flagged);
	BOOL isMine();
	BOOL isFlagged();
	int getAdj();

	void incrAdj();
	void setMine();
	
private:
	state status;
	BOOL mine;
	int numMineAdj;

};
