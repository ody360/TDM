#pragma once
#include "Includes.h"

enum CubeState { covered = 0, uncovered = 1, marked = 2 };

class CDataPoint
{
public:
	CDataPoint(void);
	~CDataPoint(void);
	BOOL isUncovered();
	void setUncovered();
	void ToggleFlagged();
	BOOL isMine();
	BOOL isFlagged();
	int getAdj();

	void incrAdj();
	void setMine();
	
private:
	CubeState status;
	BOOL mine;
	int numMineAdj;

};
