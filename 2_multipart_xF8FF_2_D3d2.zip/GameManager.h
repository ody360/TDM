#pragma once
#include "Includes.h"
#define GAMEMANAGER
#include "MineField.h"
#undef GAMEMANAGER

enum GameState { playing = 0, gameOver = 1, newGame = 2 };

class CGameManager
{
	// friend functions, they cant be member functions because
	// all member funcitons have the "hidden" paramter added, the 'this' pointer
	// Windows message processing function
	friend LRESULT CALLBACK WndProc(HWND wpHWnd, UINT msg, WPARAM wParam, LPARAM lParam);
	
	// message processing function for dialog
	friend BOOL CALLBACK DialogProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	friend class CMineField;
public:
	CGameManager();
	BOOL Initilize(HINSTANCE hInstance);
	void Run(HWND hWnd );
	HWND gethWnd(); // should get rid of later
	void Update();
	~CGameManager(void);
	// realease everything
	void Direct3DRelease();
	void SetState( GameState newState );
	GameState getState();
	
	// Whether or not it's fullscreen, and display mode
	bool m_bFullscreen;
	D3DDISPLAYMODE m_displayMode;

private:
	// describes game state
	GameState m_GameState;

	// creates and initilizes the Direct3D object
	bool Direct3DInit();

	// creates and initlizes the Direct3D device
	bool LoadD3Device();


	IDirect3DDevice8* GetDevice();

	// Important Direct3D variables
	IDirect3D8 *m_pDirect3D;
	IDirect3DDevice8 *m_pDevice;

	// The one and only minefield
	CMineField m_theField;

	HWND m_hWnd;
	HINSTANCE m_hInst;

};
