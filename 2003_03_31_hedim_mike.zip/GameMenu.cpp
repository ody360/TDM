#include "gamemenu.h"
#include "Includes.h"

CGameMenu::CGameMenu(void)
{
	memset(this,0,sizeof(CGameMenu) );
}

CGameMenu::~CGameMenu(void)
{
}

void CGameMenu::Release()
{
	//SAFE_RELEASE( m_pVertexBuffer )
	//SAFE_RELEASE( m_Texture )

	while( m_pVertexBuffer && m_pVertexBuffer->Release() );
	while( m_Texture && m_Texture->Release() );

	m_pVertexBuffer = 0;
	m_Texture = 0;
}

void CGameMenu::Redraw( IDirect3DDevice8* device )
{
    D3DXMATRIX  matWorld;
    D3DXMATRIX  matInvsView;
    D3DXMATRIX  matXWorld;
    D3DXMATRIX  matYWorld;

	D3DXVECTOR3 vCameraPosition;
	D3DXVECTOR3 vBillPosition;

	// *****  Draw the numbers ****** //
	device->SetVertexShader(D3DFVF_BILLVERTEX);
	device->SetStreamSource(0,m_pVertexBuffer,sizeof(BillVertex));
    device->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );

	// Tell it to use our texture
	// kinda works, hides ones behind it //m_pDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1 );
	device->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_SELECTARG1  );

	D3DVIEWPORT8 viewPort;
	device->GetViewport( &viewPort );

	GetRayFromMouse( device, viewPort.Width/2, viewPort.Height/2, D3DXVECTOR3(), vCameraPosition);

	device->SetTexture(0, m_Texture);

	D3DXMatrixTranslation(&matWorld, vCameraPosition.x, vCameraPosition.y, vCameraPosition.z*0.75f );

	device->SetTransform( D3DTS_WORLD, &matWorld );

	device->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 10); //draw menu..

	// release texture & vertex buffer
	device->SetStreamSource(0,0,0);
	device->SetTexture(0, NULL);

    // Restore device state
    D3DXMatrixIdentity( &matWorld );
    device->SetTransform( D3DTS_WORLD, &matWorld );

}

// x and y are the mouse coordinates in the client window
void CGameMenu::GetRayFromMouse(IDirect3DDevice8 *device, int x, int y, D3DXVECTOR3 &vPickRayDir, D3DXVECTOR3 &vPickRayOrig)
{
	D3DXMATRIX matProj;

	device->GetTransform( D3DTS_PROJECTION, &matProj );

	POINT ptCursor = { x, y };

	D3DVIEWPORT8 viewPort;
	D3DXVECTOR3 v;
	UINT width, height;

	device->GetViewport( &viewPort );

	width = viewPort.Width;
	height = viewPort.Height;

	v.x =  ( ( ( 2.0f * ptCursor.x ) / width  ) - 1 ) / matProj._11;
	v.y = -( ( ( 2.0f * ptCursor.y ) / height ) - 1 ) / matProj._22;
	v.z =  1.0f;

	// Get the inverse view matrix
	D3DXMATRIX matView, m;
	device->GetTransform( D3DTS_VIEW, &matView );
	D3DXMatrixInverse( &m, NULL, &matView );

	// Transform the screen space pick ray into 3D space
	vPickRayDir.x  = v.x*m._11 + v.y*m._21 + v.z*m._31;
	vPickRayDir.y  = v.x*m._12 + v.y*m._22 + v.z*m._32;
	vPickRayDir.z  = v.x*m._13 + v.y*m._23 + v.z*m._33;
	vPickRayOrig.x = m._41;
	vPickRayOrig.y = m._42;
	vPickRayOrig.z = m._43;
}


BOOL CGameMenu::RebuildVertexBuffer( IDirect3DDevice8 * device)
{
	HRESULT g_hr;

	BillVertex* pVerts = 0;

	if( m_Texture )
		Release();

	// now load menu texture
    if( FAILED( D3DXCreateTextureFromFile( device, "clearCube.tga", &m_Texture ) ) )
       return FALSE;

	// ****** first build the menu verticies ******** //

	// create the vertex buffer..
	g_hr = device->CreateVertexBuffer( 12*sizeof(BillVertex),
										D3DUSAGE_POINTS,
										D3DFVF_BILLVERTEX,
										D3DPOOL_DEFAULT,
										&m_pVertexBuffer );

	if( FAILED(g_hr))
		return FN_FAILED;

	g_hr = m_pVertexBuffer->Lock( 0, 12*sizeof(BillVertex), (BYTE**)&pVerts, 0 );

	if( FAILED(g_hr))
		return FN_FAILED;

	pVerts[0].SetXYZ(0,0,0);
	pVerts[1].SetXYZ(1,0,0);
	pVerts[2].SetXYZ(0,1,0);
	pVerts[3].SetXYZ(1,1,0);
	pVerts[4].SetXYZ(0,2,0);
	pVerts[5].SetXYZ(1,2,0);
	pVerts[6].SetXYZ(0,3,0);
	pVerts[7].SetXYZ(1,3,0);
	pVerts[8].SetXYZ(0,4,0);
	pVerts[9].SetXYZ(1,4,0);
	pVerts[10].SetXYZ(0,5,0);
	pVerts[11].SetXYZ(1,5,0);

	pVerts[0].SetUV(0,1);
	pVerts[1].SetUV(1,1);
	pVerts[2].SetUV(0,0.8f);
	pVerts[3].SetUV(1,0.8f);
	pVerts[4].SetUV(0,0.6f);
	pVerts[5].SetUV(1,0.6f);
	pVerts[6].SetUV(0,0.4f);
	pVerts[7].SetUV(1,0.4f);
	pVerts[8].SetUV(0,.2f);
	pVerts[9].SetUV(1,.2f);
	pVerts[10].SetUV(0,0);
	pVerts[11].SetUV(1,0);

	m_pVertexBuffer->Unlock();

	// ****** done building the menu ******** //

	return TRUE;
}

menuState CGameMenu::FindIntersect( int x, int y)
{
	D3DXVECTOR3 vPickRayDir;
	D3DXVECTOR3 vPickRayOrig;
	D3DXVECTOR3 vert1;
	D3DXVECTOR3 vert2;
	D3DXVECTOR3 vert3;
	int numVerts = 12;

	CVertex* pVerts = 0;
	//float textCordsx, textCordsy;

	menuState option;

	// get the ray from the mouse
	GetRayFromMouse( g_Game.m_pDevice, x, y, vPickRayDir, vPickRayOrig );

	// lock vertex buffer..
	m_pVertexBuffer->Lock( 0, numVerts*sizeof(CVertex), (BYTE**)&pVerts, 0 );

	for( int vertex = 0; vertex < numVerts; vertex += 1 )
	{
		vert1 = (D3DXVECTOR3)pVerts[vertex];
		vert2 = (D3DXVECTOR3)pVerts[vertex+1];
		vert3 = (D3DXVECTOR3)pVerts[vertex+2];

		if( D3DXIntersectTri( &vert1, &vert2, &vert3,
								&vPickRayOrig, &vPickRayDir,
								/*&textCordsx*/ 0, /*&textCordsy*/ 0, 0 ) )
		{
			switch( vertex )
			{
			case 2:
			case 3:
				option = basic;
				g_Game.SetState(playing);
				break;
			case 4:
			case 5:
				option = intermediate;
				g_Game.SetState(playing);
				break;
			case 6:
			case 7:
				option = expert;
				g_Game.SetState(playing);
				break;
			case 8:
			case 9:
				option = quit;
				g_Game.SetState(playing);
				break;
			default:
				break;
			}
		}

	}

		
	m_pVertexBuffer->Unlock();
	return option;
}

void CGameMenu::OnMouseClick( int x, int y, WPARAM ButtonState, UINT mouseButton )
{
	if( g_Game.getState() == inMenu )
	{
		menuState state = FindIntersect( x, y );
		switch( state )
		{
		case 1: //basic
			g_Game.SetState(playing);
			g_Game.NewGame(iCoords(3,3,3), 7);
			break;
		case 2: //intermediate
			g_Game.SetState(playing);
			g_Game.NewGame(iCoords(5,5,5), 50);
			break;
		case 3: //expert
			g_Game.SetState(playing);
			g_Game.NewGame(iCoords(10,10,10), 400);
			break;
		case 0: //exit
			PostQuitMessage(0);
			break;
		}
	}
}